// Listen for any tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // Check if the tab is active and there's a URL change
    if (tab.active && changeInfo.url) {
        // Check if transitioning from stripe.com to contexto.me
        if (lastUrl.includes("stripe.com") && changeInfo.url.includes("contexto.me")) {
            chrome.storage.local.get('user_email', function(result) {
                if (!result.user_email) {
                    updateVisibility('signupDiv');
                    console.log('No email stored');
                } else {
                    checkUserStatus(result.user_email);
                }
            });
        }
        // Update the last known URL
        lastUrl = changeInfo.url;
    }
});

document.getElementById('startParticles').addEventListener('click', () => {
    const imageUrl = "https://fastly.picsum.photos/id/9/5000/3269.jpg?hmac=cZKbaLeduq7rNB8X-bigYO8bvPIWtT-mh8GRXtU3vPc"; // Your image URL
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, {action: 'startEffect', imageUrl: imageUrl}, (response) => {
            console.log("here");
        });
    });
});

// Listen for tab activations to reset the last URL based on active tab
chrome.tabs.onActivated.addListener(activeInfo => {
    chrome.tabs.get(activeInfo.tabId, (tab) => {
        // Update the last URL for the newly activated tab
        if (tab.url) {
            lastUrl = tab.url;
        }
    });
});


let divManager;
let lastUrl = "";
let endpoint = 'https://cc-contexto-d01a6bbfa039.herokuapp.com';
let expandableHeader = document.getElementById('expandable-header');
let colorPickerContainer = document.getElementById('color-picker-container');

expandableHeader.addEventListener('click', () => {
  const isVisible = colorPickerContainer.style.display === 'block';
  colorPickerContainer.style.display = isVisible ? 'none' : 'block';
});

let colorPickers = document.querySelectorAll('input[type="color"]');

colorPickers.forEach(picker => {
    picker.addEventListener('input', () => {
      const id = picker.id;
      const color = picker.value;
  
      let message = null;
  
      switch (id) {
        case 'branding-message-color':
          message = {
            action: 'updateStyle',
            targetElementIds: ['branding_message'],
            styleProperty: 'color',
            color: color
          };
          break;
        case 'leaderboard-font-color':
          message = {
            action: 'updateStyle',
            targetElementIds: ['leaderboard', 'footer_message'],
            styleProperty: 'color',
            color: color
          };
          break;
        case 'leaderboard-bg-color':
          message = {
            action: 'updateStyle',
            targetElementIds: ['leaderboard', 'footer_message'],
            styleProperty: 'backgroundColor',
            color: color
          };
          break;
        default:
          return;
      }
  
      // Send the message to the content script (automateGame.js)
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, message);
      });
    });
  });

document.addEventListener('DOMContentLoaded', function() {
    divManager = {
        verificationDiv: document.getElementById('verificationDiv').classList,
        signupDiv: document.getElementById('signupDiv').classList,
        userDiv: document.getElementById('userDiv').classList,
        loginDiv: document.getElementById('loginDiv').classList,
        startSubDiv: document.getElementById('startSubDiv').classList,
        manageSubDiv: document.getElementById('manageSubDiv').classList,
        passwordRecoveryDiv: document.getElementById('passwordRecoveryDiv').classList,
        resetPasswordDiv: document.getElementById('resetPasswordDiv').classList,
        feedbackDiv: document.getElementById('feedbackDiv').classList
    };
});

document.addEventListener('DOMContentLoaded', function() {
    chrome.storage.local.get('user_email', function(result) {
        if (!result.user_email) {
            updateVisibility('signupDiv');
            console.log('No email stored');
        } else {
            checkUserStatus(result.user_email);
        }
    });
});

document.getElementById('verifyButton').addEventListener('click', function() {
    // Retrieve the email from Chrome's local storage
    chrome.storage.local.get('user_email', function(result) {

        if (!result.user_email) {
            alert('Please sign in again! Close and reopen extension');
            return;
        }

        const email = result.user_email;
        const verificationCode = document.getElementById('verificationCode').value;

        fetch(endpoint + '/verify-email', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, verificationCode })
        })
        .then(response => response.text())
        .then(result => {
            console.log(result);
            if (result === "email_verified") {
                alert("Thank you for verifying your email!");
                updateVisibility('loginDiv');
            } else if (result === "invalid_code") {
                alert("Try again, the code is invalid.");
            }
        })
        .catch(error => {
            console.error('Error verifying email:', error);
            alert('Error verifying email');
        });
    });
});

document.getElementById('passwordRecoveryForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const email = document.getElementById('recoveryEmail').value;
    fetch(endpoint + '/request-password-reset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
    })
    .then(response => response.json())
    .then(result => {
        if (result.message === "Failed to send password reset email.") {
            alert("Something went wrong, try again!");
            return;
        } else if (result.message === "Password reset email sent!") {
            alert("Password reset email sent!");
            updateVisibility('resetPasswordDiv');
            return;
        }
    })//adjust this
    .catch(error => {
        alert('Something went wrong, try again!');
        console.error('Error:', error);
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const feedbackForm = document.getElementById('feedbackForm');

    feedbackForm.addEventListener('submit', function(event) {
        event.preventDefault();

        // Retrieve values from form
        const feedbackEmail = document.getElementById('feedback_email').value;
        const feedbackType = document.getElementById('feedback_type').value;
        const feedbackMessage = document.getElementById('feedback_message').value;

        // Create the POST request payload
        const data = {
            feedback_email: feedbackEmail,
            feedback_type: feedbackType,
            feedback_message: feedbackMessage
        };

        // Send the POST request to the server
        fetch(endpoint + '/feedback', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            console.log('Success:', data);
            alert('Feedback submitted successfully!');
            document.getElementById('feedback_message').value = "";
            updateVisibility("userDiv");
        })
        .catch((error) => {
            console.error('Error:', error);
            alert('Failed to submit feedback.');
        });
    });
});


function clearRecentBrowsingData() {
    chrome.cookies.getAll({domain: "contexto.me"}, function(cookies) {
        for (let i = 0; i < cookies.length; i++) {
            chrome.cookies.remove({url: "https://" + cookies[i].domain + cookies[i].path, name: cookies[i].name});
        }
        console.log('All cookies for contexto.me removed.');
    });

    chrome.browsingData.remove({
        "origins": ["https://contexto.me/"]
    }, {
        "localStorage": true,
        "indexedDB": true,
        "serviceWorkers": true,
        "webSQL": true
    }, () => {
        console.log('All site-specific data cleared for contexto.me.');
    });

    alert("Reloading browser to clear site data!");
    
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.reload(tabs[0].id);
    });
}

//document.getElementById('clearDataBtn').addEventListener('click', clearRecentBrowsingData);

document.addEventListener('DOMContentLoaded', function() {
    const historyTextarea = document.getElementById('gameHistory');
    const clearHistoryButton = document.getElementById('clearHistory');

    // Function to update the textarea with the game numbers
    function updateGameHistory() {
        chrome.storage.local.get(['gameNumbers'], function(result) {
            if (result.gameNumbers && result.gameNumbers.length > 0) {
                historyTextarea.value = result.gameNumbers.join('\n');
            } else {
                historyTextarea.value = "";
            }
        });
    }

    chrome.storage.onChanged.addListener(function(changes, namespace) {
        if (namespace === 'local' && changes.gameNumbers) {
            updateGameHistory();
        }
    });

    // Call update function on load
    updateGameHistory();

    // Clear game history
    clearHistoryButton.addEventListener('click', function() {
        chrome.storage.local.set({gameNumbers: []}, function() {
            updateGameHistory();
            clearRecentBrowsingData();
        });
    });
});

document.addEventListener('DOMContentLoaded', function() {
    chrome.storage.local.get('username', function(data) {
        if (data.username) {
            data.username = data.username.replaceAll("@","");
            var tikTokUrl = `tiktok.com/@${data.username}/live`;
            document.getElementById("scrapingLabel").innerHTML = `When you go live, visit the following URL to scrape comments from your live into contexto: <b>${tikTokUrl}</b>`;
            document.getElementById("scrapingLabel").classList.remove('hidden');
            // document.getElementById('urlDisplay').textContent = tikTokUrl;
        } else {
            document.getElementById("scrapingLabel").innerHTML = `When you go live, visit the following URL to scrape comments from your live into contexto: <b>tiktok.com/@<your_username>/live</b>`;
            document.getElementById("scrapingLabel").classList.remove('hidden');
        }
    });

    // Save button for photo URL
    document.getElementById('imageSave').addEventListener('click', function() {
        const photoUrl = document.getElementById('photoUrl').value;
        if (photoUrl) {
            chrome.storage.local.set({ "photoUrl": photoUrl }, function() {
                updatePhotoPreview(photoUrl);
                console.log('Photo URL is saved');
            });
        } else {
            console.log("no photo URL added");
        }
    });



    document.querySelector('.info-icon').addEventListener('mouseenter', function() {
        document.querySelector('.hover-image').style.display = 'block';
    });
    
    document.querySelector('.info-icon').addEventListener('mouseleave', function() {
        document.querySelector('.hover-image').style.display = 'none';
    });
});

function updatePhotoPreview(url) {
    const photoPreview = document.getElementById('photoPreview');
    if (url) {
        photoPreview.src = url;
        photoPreview.style.display = 'block';
    } else {
        photoPreview.style.display = 'none';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const saveButton = document.getElementById('saveBlockedButton');
    const blockedGamesArea = document.getElementById('blockedGames');

    const defaultBlockedGames = ["0","3","4","7","8","9","10","12","12","13","18","20","24","25","29","40","43","72","79","80","83",
                                "86","91","97","103","113","118","123","130","136","139","146","148","161","167","171","173","188","203",
                                "207","217","224","234","238","239","243","249","251","254","262","265","266","302","313","326","333","335",
                                "349","371","372","390","408","421","434","437","440","455","458","459","484","514","515","559","567",
                                "568","579","581","593","600","621","628", "639", "664", "670", "682", "705", "712", "716", "722", "731", "777"];

    // Load the blocked games from storage and display them or show "No blocked games"
    chrome.storage.sync.get(['blockedGameNumbers'], function(result) {
        let blockedGameNumbers = result.blockedGameNumbers || [];

        defaultBlockedGames.forEach(game => {
            if (!blockedGameNumbers.includes(game)) {
                blockedGameNumbers.push(game);
            }
        });

        chrome.storage.sync.set({blockedGameNumbers: blockedGameNumbers}, function() {
            blockedGamesArea.value = blockedGameNumbers.join('\n');
        });
    });

    // Save the changes to the blocked games
    saveButton.addEventListener('click', function() {
        const updatedGameNumbers = blockedGamesArea.value.split('\n').filter(num => num.trim() !== '' && num !== 'No blocked games');
        chrome.storage.sync.set({blockedGameNumbers: updatedGameNumbers}, function() {
            alert('Blocked game numbers updated!');
        });
    });
});

document.getElementById('stopGame').addEventListener('click', function() {
    document.getElementById('startGame').classList.remove('inactive-button');
    document.getElementById('stopGame').classList.add('inactive-button');
    chrome.storage.local.set({'gameActive': false}, function() {
        console.log('Game has been stopped');
    });
});

document.getElementById('startButton').addEventListener('click', async () => {
    document.getElementById('startButton').classList.add('inactive-button');
    document.getElementById('stopButton').classList.remove('inactive-button');
    let [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    chrome.storage.local.set({ "scraping": true }, function() {
        console.log('scraping started');
    });
    chrome.scripting.executeScript({
        target: {tabId: tab.id},
        files: ['pushComments.js']
    });
});

document.getElementById('save').addEventListener('click', function() {
    if (document.getElementById('username').value === "") {
        console.log("no username added");
        return;
    } 
    var username = document.getElementById('username').value.replaceAll("@","");
    chrome.storage.local.set({ "username": username }, function() {
        var tikTokUrl = `tiktok.com/@${username}/live`;
        document.getElementById("scrapingLabel").innerHTML
         = `To use scraping controls to record viewer's comments while going live, visit the url: <b>${tikTokUrl}</b>`;
        document.getElementById("scrapingLabel").classList.remove('hidden');
        console.log('Username is saved');
    });
});

// Load the background URL from chrome storage and set it in the input field on popup load
document.addEventListener('DOMContentLoaded', function() {
    chrome.storage.local.get('background', function(result) {
        if (result.background) {
            document.getElementById('addBackground').value = result.background;
        }
    });
});

document.getElementById('saveBackground').addEventListener('click', function() {
    var backgroundInput = document.getElementById('addBackground').value;
    
    if (backgroundInput === "") {
        console.log("no url added");
        return;
    } 
    var background = document.getElementById('addBackground').value;
    chrome.storage.local.set({ "background": background }, function() {
        alert("Background saved")
        console.log("Background URL saved: " + backgroundInput);
    });
});

document.getElementById('stopButton').addEventListener('click', () => {
    document.getElementById('startButton').classList.remove('inactive-button');
    document.getElementById('stopButton').classList.add('inactive-button');
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        chrome.storage.local.set({ "scraping": false }, function() {
            console.log('scraping stopped');
        });
    });
});

document.getElementById('clearLeaderboard').addEventListener('click', function() {
    chrome.storage.local.set({leaderboard: {}}, () => {
        console.log('Leaderboard cleared!');
        // Optionally, send a message to content script to update the UI
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {action: "clearLeaderboard"});
        });
    });
});

document.getElementById('reviewLeaderboard').addEventListener('click', function() {
    console.log('Leaderboard in review mode!');
    if (window.confirm("Confirm to continue. After this action, you will have to refresh the page to reset the UI.")) {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {action: "reviewLeaderboard"});
        });
    } else {
        window.alert("Action aborted.")
    }
});

// document.getElementById('clearGifterboard').addEventListener('click', function() {
//     chrome.storage.local.set({gifterboard: {}}, () => {
//         console.log('Gifterboard cleared!');
//         // Optionally, send a message to content script to update the UI
//         chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
//             chrome.tabs.sendMessage(tabs[0].id, {action: "clearGifterboard"});
//         });
//     });
// });

document.addEventListener('DOMContentLoaded', function() {
    const username_input = document.getElementById('username');
    chrome.storage.local.get('username', function(result) {
        if (result.username) {
            username_input.value = result.username;
        }
    });
    const photo_input = document.getElementById('photoUrl');
    chrome.storage.local.get('photoUrl', function(result) {
        if (result.photoUrl) {
            photo_input.value = result.photoUrl;
            updatePhotoPreview(result.photoUrl)
        }
    });

});

document.getElementById('startGame').addEventListener('click', async () => {
    document.getElementById('startGame').classList.add('inactive-button');
    document.getElementById('stopGame').classList.remove('inactive-button');
    // Listen for messages from the content script
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        if (request.gameNumber) {
            document.getElementById('gameNumberInput').value = request.gameNumber;
        }
    });
    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        if (request.gameAnswer) {
            document.getElementById('gameAnswerInput').value = request.gameAnswer;
        }
    });
    let [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    console.log("executing");
    chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['automateGame.js']
    });

    // Also fetch the game number from local storage when the popup is opened
    chrome.storage.local.get('gameNumber', function(data) {
        if (data.gameNumber) {
            document.getElementById('gameNumberInput').value = data.gameNumber;
        }
    });
    chrome.storage.local.get('gameAnswer', function(data) {
        if (data.gameAnswer) {
            document.getElementById('gameAnswerInput').value = data.gameAnswer;
        }
    });
});

document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    const emailError = document.getElementById('emailError');
    const passwordError = document.getElementById('passwordError');
    const confirmPasswordError = document.getElementById('confirmPasswordError');

    emailError.style.display = 'none';
    passwordError.style.display = 'none';
    confirmPasswordError.style.display = 'none';

    const emailValid = validateEmail(email);
    const passwordValid = validatePassword(password);
    const passwordsMatch = password === confirmPassword;

    if (!emailValid) {
        emailError.style.display = 'block';
        return;
    }
    if (!passwordValid) {
        passwordError.style.display = 'block';
        return;
    }
    if (!passwordsMatch) {
        confirmPasswordError.style.display = 'block';
        return;
    }

    console.log('Form submitted successfully!');
    signUp(email, password);
});

document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    const emailError = document.getElementById('loginEmailError');
    const passwordError = document.getElementById('loginPasswordError');

    emailError.style.display = 'none';
    passwordError.style.display = 'none';

    const emailValid = validateEmail(email);
    const passwordValid = validatePassword(password);

    if (!emailValid) {
        emailError.style.display = 'block';
        return;
    }
    if (!passwordValid) {
        passwordError.style.display = 'block';
        return;
    }

    console.log('Form submitted successfully!');
    login(email, password);
});

document.getElementById('resetPasswordForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const token = document.getElementById('resetToken').value;
    const email = document.getElementById('resetEmail').value;
    const newPassword = document.getElementById('newPassword').value;
    const passwordError = document.getElementById('newPasswordError');

    const passwordValid = validatePassword(newPassword);
    if (!passwordValid) {
        passwordError.style.display = 'block';
        return;
    }
    console.log('Reset form submitted successfully!');
    resetPassword(token, email, newPassword);
});

function resetPassword(token, email, newPassword) {
    fetch(endpoint + '/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, email, newPassword })
    })
    .then(response => response.json())
    .then(result => {
        if (result.message === "Invalid/Expired token or wrong email entered") {
            alert("Invalid/Expired token or wrong email entered");
            return;
        } else if (result.message === "Password has been reset successfully.") {
            alert("Password changed successfully!");
            updateVisibility('loginDiv');
            return;
        }
    })//handle result
    .catch(error => {
        console.error('Error:', error);
        alert('Something went wrong, fix any issues and submit again.');
    });
}

function clearEmail() {
    chrome.storage.local.remove('user_email', function() {
        console.log('Email cleared from storage');
    });
}

function validateEmail(email) {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
}

function validatePassword(password) {
    const capitalLetter = /[A-Z]/;
    const number = /[0-9]/;
    const specialCharacter = /[!@#\$%\^&\*\-_+=\[\]\{\};:,.<>?]/; // Allowed special characters

    return capitalLetter.test(password) && number.test(password) && specialCharacter.test(password) &&
           !/[ '";<>\\\|&\$(){}]/.test(password) && password.length > 7; // Disallowed special characters
}

// Function to handle the signup
function signUp(email, password) {
    const data = {
        email: email,
        password: password
    };
    const fetchOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    };
    // Sending the POST request to the server
    fetch(endpoint + '/signup', fetchOptions)
        .then(response => response.json())  // Parsing the JSON response
        .then(result => {
            if (result.message === 'Signup successful!') {
                console.log('Success:', result);
                displayVerificationInput(email);
            } else if (result.message === "Email already exists") {
                alert('Email already exists');
            } else {
                throw new Error('Signup failed');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Something went wrong, submit again.');
        });
}

function displayVerificationInput(email) {
    const signupDiv = document.getElementById('signupDiv');
    const verificationDiv = document.getElementById('verificationDiv');

    // Store email in Chrome's local storage
    chrome.storage.local.set({ user_email: email }, function() {
        console.log('Email stored successfully');
        updateVisibility('verificationDiv');
    });
}

function login(email, password) {
    const data = {
        email: email,
        password: password
    };
    const fetchOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    };
    // Sending the POST request to the server
    fetch(endpoint + '/login', fetchOptions)
        .then(response => response.json())  // Parsing the JSON response
        .then(result => {
            if (result.message === 'Login successful!') {
                console.log('Success:', result);
                chrome.storage.local.set({ user_email: email }, function() {
                    console.log('Email stored successfully');
                    checkUserStatus(email);
                });
                alert("Login successful!");
            } else {
                console.log("Username or password is incorrect!");
                alert("Username or password is incorrect!");
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Something went wrong, submit again.');
        });
}

document.getElementById('startSubscription').addEventListener('click', function() {
    chrome.storage.local.get('user_email', function(result) {
        const userEmail = result.user_email;
        const data = { email: userEmail };

        const fetchOptions = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        };

        fetch(endpoint + '/create-checkout-session', fetchOptions)
            .then(response => response.json())
            .then(result => {
                console.log('Checkout session created:', result);
                changeActiveTabLocation(result.url);
            })
            .catch(error => {
                console.error('Error creating checkout session:', error);
            });
    });
});

function checkUserStatus(email) {
    fetch(endpoint + `/check-user?email=${encodeURIComponent(email)}`)
        .then(response => response.text())  // Assuming the response is plain text as per your endpoint
        .then(result => {
            console.log(result);
            switch (result) {
                case "email_not_found":
                    console.log("No email was provided or user not found.");
                    updateVisibility('signupDiv');
                    //need a login section here
                    break;
                case "found_but_not_verified":
                    console.log("User found but the email is not verified.");
                    updateVisibility('verificationDiv');
                    break;
                case "found_and_active":
                    console.log("User found with an active or trialing subscription.");
                    updateVisibility('userDiv');
                    break;
                case "found_and_not_active":
                    console.log("User found but the subscription is not active.");
                    updateVisibility('manageSubDiv');
                    break;
                case "found_and_none":
                    console.log("User found but did not make it to subscription.");
                    updateVisibility('startSubDiv');
                    break;
                default:
                    console.log("Unexpected result:", result);
            }
        })
        .catch(error => {
            console.error("Error checking user status:", error);
            updateVisibility('signupDiv');
            alert("Error: Please sign in.");
        });
}

function changeActiveTabLocation(newUrl) {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.update(tabs[0].id, {url: newUrl});
    });
}

function updateVisibility(visibleDivId) {
    // Iterate over each div in the manager
    for (const [divId, classList] of Object.entries(divManager)) {
        // Check if the current div is the one that should be visible
        if (divId === visibleDivId) {
            classList.remove('hidden'); // Show the div
        } else {
            classList.add('hidden'); // Hide other divs
        }
    }
}

//SETTINGS CONTAINER
document.addEventListener('DOMContentLoaded', function() {
    const hintGiftDropdown = document.getElementById('hintGift');

    // Load the currently selected option from storage
    chrome.storage.local.get(['hint_gift'], function(result) {
        if (result.hint_gift) {
            hintGiftDropdown.value = result.hint_gift;
        } else {
            hintGiftDropdown.value = 'rose'; // Default value
            chrome.storage.local.set({'hint_gift': 'rose'});
        }
    });

    // Event listener for changes in the dropdown
    hintGiftDropdown.addEventListener('change', function() {
        chrome.storage.local.set({'hint_gift': hintGiftDropdown.value});
    });

    const endGiftDropdown = document.getElementById('endGift');

    // Load the currently selected option from storage
    chrome.storage.local.get(['end_gift'], function(result) {
        if (result.end_gift) {
            endGiftDropdown.value = result.end_gift;
        } else {
            endGiftDropdown.value = 'corgie'; // Default value
            chrome.storage.local.set({'end_gift': 'corgie'});
        }
    });

    // Event listener for changes in the dropdown
    endGiftDropdown.addEventListener('change', function() {
        chrome.storage.local.set({'end_gift': endGiftDropdown.value});
    });

    // Existing code to toggle the settings visibility
    document.querySelector('.settings-toggle-button').addEventListener('click', function() {
        var settingsContent = document.querySelector('.settings-content');
        if (settingsContent.style.display === 'block') {
            settingsContent.style.display = 'none';
        } else {
            settingsContent.style.display = 'block';
        }
    });

    document.querySelector('.game-info-toggle-button').addEventListener('click', function() {
        var gameInfoContent = document.querySelector('.game-info-content');
        if (gameInfoContent.style.display === 'block') {
            gameInfoContent.style.display = 'none';
        } else {
            gameInfoContent.style.display = 'block';
        }
    });

    document.querySelector('.account-toggle-button').addEventListener('click', function() {
        var accountContent = document.querySelector('.account-content');
        if (accountContent.style.display === 'block') {
            accountContent.style.display = 'none';
        } else {
            accountContent.style.display = 'block';
        }
    });

    chrome.storage.local.get(['user_email'], function(result) {
        const userEmail = result.user_email;
        if (userEmail) {
            document.getElementById('feedback_email').value = userEmail;
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const gameModeDropdown = document.getElementById('gameMode');

    // Load the currently selected option from storage
    chrome.storage.local.get(['game_mode'], function(result) {
        if (result.game_mode) {
            gameModeDropdown.value = result.game_mode;
        } else {
            gameModeDropdown.value = 'automated'; // Default value
            chrome.storage.local.set({'game_mode': 'automated'});
        }
    });

    // Event listener for changes in the dropdown
    gameModeDropdown.addEventListener('change', function() {
        chrome.storage.local.set({'game_mode': gameModeDropdown.value});
    });

    const scrapeModeDropdown = document.getElementById('scrapeMode');

    // Load the currently selected option from storage
    chrome.storage.local.get(['scrape_mode'], function(result) {
        if (result.scrape_mode) {
            scrapeModeDropdown.value = result.scrape_mode;
        } else {
            scrapeModeDropdown.value = 'comments_and_gifts'; // Default value
            chrome.storage.local.set({'scrape_mode': 'comments_and_gifts'});
        }
    });

    // Event listener for changes in the dropdown
    scrapeModeDropdown.addEventListener('change', function() {
        chrome.storage.local.set({'scrape_mode': scrapeModeDropdown.value});
    });

    const leaderboardModeDropdown = document.getElementById('leaderboardMode');

    // Load the currently selected option from storage
    chrome.storage.local.get(['leaderboard_mode'], function(result) {
        if (result.leaderboard_mode) {
            leaderboardModeDropdown.value = result.leaderboard_mode;
        } else {
            leaderboardModeDropdown.value = 'on'; // Default value
            chrome.storage.local.set({'leaderboard_mode': 'on'});
        }
    });

    // Event listener for changes in the dropdown
    leaderboardModeDropdown.addEventListener('change', function() {
        chrome.storage.local.set({'leaderboard_mode': leaderboardModeDropdown.value});
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const brandingSlider = document.getElementById('brandingSlider');

    // Load the current state from storage and update the slider
    chrome.storage.local.get('branding_message', function(data) {
        brandingSlider.checked = data.branding_message !== 'off';
    });

    // Update storage whenever the slider changes
    brandingSlider.addEventListener('change', function() {
        if(brandingSlider.checked) {
            chrome.storage.local.set({ 'branding_message': 'on' });
        } else {
            chrome.storage.local.set({ 'branding_message': 'off' });
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const messageBoxSlider = document.getElementById('messageBoxSlider');

    chrome.storage.local.get('message_box', function(data) {
        messageBoxSlider.checked = data.message_box !== 'off';
    });

    messageBoxSlider.addEventListener('change', function() {
        if(messageBoxSlider.checked) {
            chrome.storage.local.set({ 'message_box': 'on' });
        } else {
            chrome.storage.local.set({ 'message_box': 'off' });
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Check for the 'gameActive' storage value and update buttons accordingly
    chrome.storage.local.get('gameActive', function(result) {
        if (!result.gameActive) {
            document.getElementById('startGame').classList.remove('inactive-button');
            document.getElementById('stopGame').classList.add('inactive-button');
        } else {
            document.getElementById('startGame').classList.add('inactive-button');
            document.getElementById('stopGame').classList.remove('inactive-button');
        }
    });

    // Check for the 'scraping' storage value and update buttons accordingly
    chrome.storage.local.get('scraping', function(result) {
        if (result.scraping) {
            document.getElementById('startButton').classList.add('inactive-button');
            document.getElementById('stopButton').classList.remove('inactive-button');
        } else {
            document.getElementById('startButton').classList.remove('inactive-button');
            document.getElementById('stopButton').classList.add('inactive-button');
        }
    });
});

document.getElementById('loginFromSignup').addEventListener('click', () => updateVisibility('loginDiv'));
document.getElementById('signupFromLogin').addEventListener('click', () => updateVisibility('signupDiv'));
document.getElementById('manageSubButton').addEventListener('click', () => changeActiveTabLocation("https://billing.stripe.com/p/login/aEU9D55NEeZr2di000"));
document.getElementById('manageSubOnUser').addEventListener('click', () => changeActiveTabLocation("https://billing.stripe.com/p/login/aEU9D55NEeZr2di000"));
document.getElementById('forgotPasswordOnLogin').addEventListener('click', function(event) {
    event.preventDefault();
    updateVisibility('passwordRecoveryDiv');
});
document.getElementById('feedbackFromAccount').addEventListener('click', function(event) {
    event.preventDefault();
    updateVisibility('feedbackDiv');
});
document.getElementById('loginOnPasswordRecovery').addEventListener('click', function(event) {
    event.preventDefault();
    updateVisibility('loginDiv');
});
document.getElementById('loginOnResetPassword').addEventListener('click', function(event) {
    event.preventDefault();
    updateVisibility('loginDiv');
});
document.getElementById('backToGameControls').addEventListener('click', function(event) {
    event.preventDefault();
    updateVisibility('userDiv');
});
document.getElementById('logoutButton').addEventListener('click', function() {
    chrome.storage.local.set({'user_email': ''}, function() {
        console.log('User email has been cleared.');
        updateVisibility('loginDiv');
    });
});
