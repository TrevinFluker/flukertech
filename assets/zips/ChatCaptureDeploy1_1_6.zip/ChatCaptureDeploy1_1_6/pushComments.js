(async function() {

    var loggedInUser = "";
    let endpoint = 'https://cc-contexto-d01a6bbfa039.herokuapp.com';
    const targetElement = document.querySelector('[class*="-DivChatMessageList"]');
    const unreadTarget = document.querySelector('[class*="DivChatRoomBody"]');
    const giftTarget = document.querySelector('[class*="-1v0f6mm-StyledGiftTray"]');

    let observer;
    let giftTargetObserver;
    let giftFromTarget;

    chrome.storage.local.get("username", function(result) {
        if (result.username) {
            console.log("Retrieved username: " + result.username);
            loggedInUser = result.username;
        } else {
            alert("Add a username to begin scraping comments");
        }
    });

    var lastDetails = {
        nickname: "",
        comment: "",
        profilePhotoUrl: ""
    };

    var lastGiftDetails = {
        nickname: "",
        profilePhotoUrl: "",
        giftTotal: "",
        giftImageUrl: ""
    };

    function createToastElement() {
        // Create the toast container
        const toast = document.createElement('div');
        toast.id = 'toast';
        toast.style.display = 'none';
        toast.style.position = 'fixed';
        toast.style.left = '0';      // Full width from left to right
        toast.style.right = '0';     // Full width from left to right
        toast.style.width = 'fit-content';  // Auto width based on content
        toast.style.margin = 'auto'; // Auto margins to center horizontally
        toast.style.top = '100px';
        toast.style.padding = '10px';
        toast.style.backgroundColor = 'black';
        toast.style.color = 'white';
        toast.style.zIndex = '1000';
        toast.style.borderRadius = '5px';
    
        // Create the text element for the toast
        const toastText = document.createElement('p');
        toastText.id = 'toast-text';
        toastText.innerHTML = 'This is a toast message';
    
        // Append text element to toast container
        toast.appendChild(toastText);
    
        // Append toast container to the body
        document.body.appendChild(toast);
    }

    function showToast(details, type) {
        console.log('showing toast');
        const toast = document.getElementById('toast');
        const toastText = document.getElementById('toast-text');
        
        if (type === "message") {
            // Use innerHTML to insert HTML content for styling and line breaks
            toastText.innerHTML = `<b>New comment saved:</b> ${details.comment}<br>
                               <b>Username:</b> ${details.nickname}`;
        } else {
            // Use innerHTML to insert HTML content for styling and line breaks
            toastText.innerHTML = `<b>New gift saved from:</b> ${details.nickname}`;
        }

        toast.style.display = 'block';
        setTimeout(() => {
            toast.style.display = 'none';
        }, 3000);
    }

    async function fetchAndDisplayMessageDetails() {
        // Select the parent container using the updated class name
        const parent = document.querySelector('[class*="-DivChatMessageList"]');
        
        if (!parent) {
            console.log("Parent container not found.");
            return;
        }
        
        // Select all messages inside the parent container using the updated class name
        const messages = parent.querySelectorAll('[class*="-DivChatMessage"]');
        
        if (messages.length === 0) {
            console.log("No messages found.");
            return;
        }
    
        // Get the last message in the list
        const lastMessage = messages[messages.length - 1];
        //need to wait for photos to populate
        await sPause(300);
        // Extracting details from the last message
        const details = {
            host: loggedInUser,
            nickname: lastMessage.querySelector('[class*="-SpanNickName"]')?.innerText || 'Nickname not found',
            comment: lastMessage.querySelector('[class*="1kue6t3-DivComment"]')?.innerText || 'Comment not found',
            profilePhotoUrl: lastMessage.querySelector('[class*="-DivLeadIcon"] img')?.src || 'Profile photo URL not found',
            checked: "no"
        };

        console.log("scraper scanning");

        if (lastDetails.nickname === details.nickname && lastDetails.comment === details.comment) {
            return;
        }
        if (loggedInUser === "") {
            return;
        }

        chrome.storage.local.get("scraping", async function(result) {

            if (result.scraping) {

                chrome.storage.local.get("scrape_mode", async function(scrape_result) {
                    
                    if (scrape_result.scrape_mode === "comments_and_gifts") {
                        // Post the details object to the specified endpoint
                        try {
                            const response = await fetch(endpoint + '/comments', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify(details)
                            });
                            showToast(details, "message");
                            const responseData = await response.json();
                            console.log('Post successful');
                        } catch (error) {
                            console.error('Failed to post details:', error);
                        }

                        lastDetails = details;
                    
                        // Output the details object
                        console.log(JSON.stringify(details)); // Use JSON.stringify to ensure the full URL is visible if console abbreviates
                    }

                });

            } else {
                //clearInterval(scrapeInterval);
                stopObserving();
            }
        }); 
    }

    async function fetchAndDisplayGiftDetails() {
        // Select the parent container using the updated class name
        const parent = document.querySelector('[class*="-DivChatMessageList"]');
        
        if (!parent) {
            console.log("Parent container not found.");
            return;
        }
        
        // Select all messages inside the parent container using the updated class name
        const gifts = parent.querySelectorAll('[class*="-15hhtcj"]');
        
        if (gifts.length === 0) {
            console.log("No messages found.");
            return;
        }

        // Get the last message in the list
        const lastGift = gifts[gifts.length - 1];

        await sPause(300);
        // Extracting details from the last message
        const giftDetails = {
            host: loggedInUser,
            giftTotal: lastGift.querySelector('[class*="8juc6m"]')?.innerText || 'Gift total not found',
            nickname: lastGift.querySelector('[class*="101i1gy-SpanNickName"]')?.innerText || 'Nickname not found',
            giftImage: lastGift.querySelector('[class*="8juc6m"] img')?.src || 'Gift image not found',
            profilePhotoUrl: lastGift.querySelector('[class*="DivLeadIcon"] img')?.src || 'Profile photo URL not found',
            checked: "no"
        };

        if (lastGiftDetails.nickname === giftDetails.nickname && lastGiftDetails.giftTotal === giftDetails.giftTotal && lastGift.classList.contains('gift-checked')) {
            return;
        }
        if (loggedInUser === "") {
            return;
        }

        lastGift.classList.add('gift-checked');
        
        chrome.storage.local.get("scraping", async function(result) {
            if (result.scraping) {
                // Post the details object to the specified endpoint
                try {
                    const response = await fetch(endpoint + '/gifts', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(giftDetails)
                    });
                    showToast(giftDetails, "gift");
                    const responseData = await response.json();
                    console.log('Post successful:', responseData);
                } catch (error) {
                    console.error('Failed to post details:', error);
                }

                lastGiftDetails = giftDetails;
            
                // Output the details object
                console.log(JSON.stringify(giftDetails)); // Use JSON.stringify to ensure the full URL is visible if console abbreviates
            }
        }); 
    }

    function giftTargetCallback(mutationsList) {
        
        for(let mutation of mutationsList) {
            console.log(mutation);
            if (mutation.type === 'childList' && mutation.removedNodes.length > 0) {
                mutation.removedNodes.forEach(node => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        console.log('A child node has been removed.');
                        chrome.storage.local.get("scraping", async function(result) {
                            if (result.scraping) {
                                // Post the details object to the specified endpoint
                                try {
                                    giftFromTarget = node;
                                    const gftDetails = {
                                        host: loggedInUser,
                                        giftTotal: giftFromTarget.querySelector('[class*="arje3t-SpanBullet"]')?.innerText || 'Gift total not found',
                                        nickname: giftFromTarget.querySelector('[class*="-DivTitleGift"]')?.innerText || 'Nickname not found',
                                        giftImage: giftFromTarget.querySelector('[class*="r0qtcd-DivGiftBarIcon"] img')?.src || 'Gift image not found',
                                        profilePhotoUrl: giftFromTarget.querySelector('[class*="1xfcxxd-DivSendGiftAvatar"] img')?.src || 'Profile photo URL not found',
                                        checked: "no"
                                    };
                                    const response = await fetch(endpoint + '/gifts', {
                                        method: 'POST',
                                        headers: {
                                            'Content-Type': 'application/json'
                                        },
                                        body: JSON.stringify(gftDetails)
                                    });
                                    
                                    showToast(gftDetails, "gift");
                                    const responseData = await response.json();
                                    console.log('Gift post successful');
                                    // Output the details object
                                    console.log(JSON.stringify(gftDetails)); // Use JSON.stringify to ensure the full URL is visible if console abbreviates
                                } catch (error) {
                                    console.error('Failed to post details:', error);
                                }
                            } else {
                                stopObservingGiftTarget();
                            }
                        }); 
                        
                    }
                });
            }
        }
    };

    // Define the function to be called when a mutation occurs
    function handleMutation(mutations) {
    mutations.forEach(mutation => {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        // Call your specific function here
        fetchAndDisplayMessageDetails();
        //Add function to get gifts here
        //fetchAndDisplayGiftDetails();
        }
    });
    }

    function startObserving() {
        if (targetElement) {
          // Create a new MutationObserver instance and pass the callback function
          observer = new MutationObserver(handleMutation);
      
          // Define the configuration for the observer:
          const config = {
            childList: true,  // Observes direct children additions and removals
            subtree: false
          };
      
          // Start observing the target element
          observer.observe(targetElement, config);
          console.log('Observer has started');
        } else {
          console.log('Target element not found');
        }

        if (giftTarget) {
            if (!giftTargetObserver) { // Check if the observer is already initialized
                giftTargetObserver = new MutationObserver(giftTargetCallback);
                
                const giftTargetConfig = { childList: true, subtree: false, attributes: false, characterData: false  };
                giftTargetObserver.observe(giftTarget,giftTargetConfig);
            }
        }
      }
      
      // Function to stop observing
      function stopObserving() {
        if (observer) {
            observer.disconnect();
            observer = null;
            giftTargetObserver.disconnect();
            giftTargetObserver = null;
            console.log('Post observer has been disconnected');
            console.log('Gift observer has been disconnected');
        }
      }


      function checkAndClickElement() {
        const element = document.querySelector('[class*="DivUnreadTipsContent"]');
        if (element) {
            element.click();
            console.log('Element found and clicked.');
        }
      }

    const sPause = (milliseconds) => {
        return new Promise(resolve => setTimeout(resolve, milliseconds));
    };


    if (unreadTarget) {
        // Create a MutationObserver instance and set up the callback
        const unreadObserver = new MutationObserver((mutations) => {
            mutations.forEach(mutation => {
                if (mutation.type === 'childList') {
                    checkAndClickElement();
                }
            });
        });

        // Start observing the target element with the specified configuration
        unreadObserver.observe(unreadTarget, {
            childList: true,  // Observes direct children additions and removals
            subtree: true    // Observes all descendants, not just direct children
        });

        console.log('Observer has started on', unreadTarget);
    } else {
        console.log('Unread target element not found');
    }

    function stopUnreadObserving(observer) {
        if (observer) {
            observer.disconnect();
            console.log('Observer has been disconnected');
        }
    }

    createToastElement();
    // Repeat the process every second
    //let scrapeInterval = setInterval(fetchAndDisplayMessageDetails, 1000);
    startObserving();

})();
