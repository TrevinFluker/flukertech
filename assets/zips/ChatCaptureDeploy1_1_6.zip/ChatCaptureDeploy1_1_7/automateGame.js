(async function() {
    console.log("running");

    var endpoint = 'https://cc-contexto-d01a6bbfa039.herokuapp.com';
    var currentGame = "";
    var loggedInUser = "";
    var loggedInProfileImage = "https://t3.ftcdn.net/jpg/00/64/67/52/360_F_64675209_7ve2XQANuzuHjMZXP3aIYIpsDKEbF5dD.jpg";
    var currentAnswer = "";
    var executingGifts = false;
    var starting = true;
    var skip = 0;
    var endingUsers = [];
    var guessedWords = [];
    var donutUsers = [
        "Flip Match",
        "Ellie",
        "Paige",
        "dominic",
        "Mona Lulu",
        "Conner 😵‍💫",
        "FisherFN 🧌",
        "taliyah ⚽️💕."
    ]

    var endGifts = {
        corgie: "https://p16-webcast.tiktokcdn.com/img/maliva/webcast-va/148eef0884fdb12058d1c6897d1e02b9~tplv-obj.png",
        forever_rosa: "https://p16-webcast.tiktokcdn.com/img/maliva/webcast-va/resource/863e7947bc793f694acbe970d70440a1.png~tplv-obj.png",
        money_gun: "https://p16-webcast.tiktokcdn.com/img/maliva/webcast-va/e0589e95a2b41970f0f30f6202f5fce6~tplv-obj.png"
    }

    var loadingInterval;

    const sounds = {
        "victory": "https://www.myinstants.com/media/sounds/victory_6.mp3",
        "tick": "https://d3li2vbp4mtkrw.cloudfront.net/y37gor%2Ffile%2Fb9ab0212ae57ec34c21b02c95cb61828_8e061324242cd68b60dd9614e1ed7715.mp3?response-content-disposition=inline%3Bfilename%3D%22b9ab0212ae57ec34c21b02c95cb61828_8e061324242cd68b60dd9614e1ed7715.mp3%22%3B&response-content-type=audio%2Fmpeg&Expires=1722919482&Signature=egbwxHAqynPnFHq8m8i1oAwo75a5Jq3BPjXJ~NZuCp0yxiO0tjt0JDtn~FWqH6AX0LcomxW2YAKKbZPjV0GP1jIdyPiNaNXUfqALohnjr4FRRwncAZN1fdEwKZTg9xJ0pmlls1lG1~~f2DuTe1YxvmbeDsmFaZgGysvPb-nGAtbhB~jtaEx3Gs8tsSqa4zWSiyJuT4a1OORC1~-JNtC3aXxdl9xEWwPHCGuiImZHh36aPMfBhl8bSuymeLKz0mk7jF7KS-8vsJWrI5lnl7cizfhPZySxrjcnDbsQsaRsdW2u8W1r~GR~8ReyHAnsG726vdAlFDH3~kDfjoCNByk1iw__&Key-Pair-Id=APKAJT5WQLLEOADKLHBQ",
        "rose": "https://www.myinstants.com/media/sounds/thank.mp3",
        "finger_heart": "https://www.myinstants.com/media/sounds/snapchat_notification_sound_effect-eim6i3us.mp3",
        "tiny_diny": "https://www.myinstants.com/media/sounds/dinosaur-roar.mp3",
        "donut": "https://www.myinstants.com/media/sounds/homer-donut.mp3"
    };



    chrome.storage.local.get("username", function(result) {
        if (result.username) {
            console.log("Retrieved username: " + result.username);
            loggedInUser = result.username;
        } else {
            alert("Add a username to begin scraping comments");
        }
    });

    chrome.storage.local.get("photoUrl", function(result) {
        if (result.photoUrl) {
            console.log("Retrieved profile photo: " + result.photoUrl);
            loggedInProfileImage = result.photoUrl;
        } else {
            alert("Add a profile photo to display for your audience when you guess on screen")
        }
    })

    chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
        if (message.action === "clearLeaderboard") {
            renderLeaderboard("play");
        } else if (message.action === "reviewLeaderboard") {
            renderLeaderboard("review");
            seeFullLeaderboard();
        }
    });

    // Listen for messages from the popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'updateStyle') {
        const { targetElementIds, styleProperty, color } = request;
    
        targetElementIds.forEach(elementId => {
            const targetElement = document.getElementById(elementId);
            
            if (targetElement) {
            targetElement.style[styleProperty] = color;
            console.log(`Updated ${styleProperty} of #${elementId} to ${color}`);
            } else {
            console.warn(`Element with id "${elementId}" not found.`);
            }
        });
    
        // Optionally send a response back
        sendResponse({ status: 'success' });
        }
    });
  
    // chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    //     if (message.action === "clearGifterboard") {
    //         renderGifterboard();
    //     }
    // });

    const sPause = (milliseconds) => {
        return new Promise(resolve => setTimeout(resolve, milliseconds));
    };

    await sPause(1000);

    function injectCSS() {
        const css = `
            #custom-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0);
                z-index: 9999;
                pointer-events: none;
            }

            .falling-image {
                position: absolute;
                animation: fall linear infinite, sway 2s ease-in-out infinite;
            }

            @keyframes fall {
                0% { top: -100px; opacity: 1; }
                100% { top: 100vh; opacity: .75; }
            }

            @keyframes sway {
                0%, 100% { transform: translateX(0); }
                50% { transform: translateX(20px); }
            }

            .floating-text {
                font-size: 3rem;
                font-weight: bold;
                color: #333;
                animation: float 3s ease-in-out infinite;
            }
    
            @keyframes float {
                0%, 100% {
                    transform: translateY(0);
                }
                50% {
                    transform: translateY(-4px);
                }
            }
        `;
        const style = document.createElement('style');
        style.textContent = css;
        document.head.appendChild(style);
    }

    // Function to create a clear overlay
    function createOverlay() {
        if (!document.getElementById('custom-overlay')) {
            const overlay = document.createElement('div');
            overlay.id = 'custom-overlay';
            document.body.appendChild(overlay);
        }
    }

    function startEffect(imageUrl) {
        createOverlay();

        // Create a number of falling images
        for (let i = 0; i < 70; i++) {
            const img = document.createElement('img');
            img.src = imageUrl;
            img.className = 'falling-image';
            img.style.left = 20 + Math.random() * 50 + 'vw';  // Confine images to middle 50% of viewport
            img.style.top = Math.random() * -100 + 'px';
            img.style.width = img.style.height = Math.random() * (50 - 30) + 30 + 'px';
            img.style.animationDuration = `${3 + Math.random() * 2}s, 2s`;
            img.style.animationDelay = `${Math.random() * 2}s, 0s`;
            document.getElementById('custom-overlay').appendChild(img);

            // Remove the image after the animation is done
            setTimeout(() => {
                img.remove();
            }, 5000); // 5 seconds to account for the longest animation duration
        }

        // Remove the overlay after the effect is done
        setTimeout(() => {
            document.getElementById('custom-overlay').remove();
        }, 5000); // 5 seconds to account for the longest animation duration
    }

    // chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    //     if (request.action === 'startEffect') {
    //         startEffect(request.imageUrl);
    //         sendResponse({status: 'Effect started'});
    //     }
    // });

    // Function to check comment and update skip value
    function checkEndGame(username, comment) {
        if (comment === "#endgame") {
            if (!endingUsers.includes(username)) {
                endingUsers.push(username);
                skip += 1;
            }
        }
        if (skip > 7) {
            endingUsers = [];
            skip = 0;
            return true;
        } else {
            return false;
        }
    }

    async function insertBrandingMessage() {
        let giftValue = await getHintGift();
        let giftIcon = '';

        if (giftValue === "rose") {
            giftIcon = '🌹';
        }
        if (giftValue === "finger_heart") {
            giftIcon = '🫰🏼❤️';
        }
        if (giftValue === "tiny_diny") {
            giftIcon = '🦖';
        }
        if (giftValue === "donut") {
            giftIcon = '🍩';
        }

        if (!document.getElementById("branding_message")) {
            const brandingDiv = document.createElement('div');
            brandingDiv.id = 'branding_message';
            brandingDiv.style.position = 'absolute'; // Use 'absolute' so it positions relative to the target element
            brandingDiv.style.left = '0';
            brandingDiv.style.right = '0';
            brandingDiv.style.textAlign = 'center';
            brandingDiv.style.display = 'block'; // Default display
            if (giftValue === "no_gift") {
                brandingDiv.innerHTML = 'Type to play; Words with lower numbers are closer to the secret.';
            } else {
                brandingDiv.innerHTML = 'Type to play; Words with lower numbers are closer to the secret. '+ giftIcon +' for hint.';
            }
            brandingDiv.style.backgroundColor = "transparent";
            brandingDiv.style.width = "fit-content";
            brandingDiv.style.margin = "auto";
            brandingDiv.style.zIndex = "10";
            brandingDiv.style.fontSize = "13px";
            brandingDiv.classList.add('floating-text');
            document.body.appendChild(brandingDiv);
    
            // Function to update the branding message position
            function updateBrandingPosition() {
                const targetInput = document.querySelector('main form input');
                if (targetInput) {
                    const rect = targetInput.getBoundingClientRect();
                    brandingDiv.style.top = `${window.scrollY + rect.bottom + 2}px`; // Position below form input with a 5px margin
                }
            }
    
            // Set initial position
            updateBrandingPosition();
    
            // Update position on window resize or scroll
            window.addEventListener("resize", updateBrandingPosition);
            window.addEventListener("scroll", updateBrandingPosition);
    
            // Additional styling for siteName element after delay
            // setTimeout(() => {
            //     const siteNameStyle = document.getElementById("siteName").style;
            //     siteNameStyle.color = "white";
            //     siteNameStyle.backgroundColor = "black";
            //     siteNameStyle.padding = "1px 5px";
            //     siteNameStyle.borderRadius = "6px";
            // }, 500);
        }
    }
    

    function insertMessageBox() {
        if (!document.getElementById("message_box")) {
            const messageDiv = document.createElement('div');
            messageDiv.id = 'message_box';
            messageDiv.contentEditable = 'true';
            messageDiv.style.position = 'absolute'; // Use 'absolute' to position based on the target element
            messageDiv.style.textAlign = 'right';
            messageDiv.style.display = 'block';
            messageDiv.innerHTML = "Follow & Play";
            messageDiv.style.backgroundColor = "transparent";
            messageDiv.style.width = "250px";
            messageDiv.style.margin = "auto";
            messageDiv.style.zIndex = "10";
            messageDiv.style.overflow = "auto";
            messageDiv.style.whiteSpace = "nowrap";
            messageDiv.style.scrollbarWidth = "none";
            messageDiv.style.color = "#d23434";
            document.body.appendChild(messageDiv);
    
            // Function to update message box position
            function updateMessageBoxPosition() {
                const targetInput = document.querySelector('main form input');
                if (targetInput) {
                    const rect = targetInput.getBoundingClientRect();
                    messageDiv.style.top = `${window.scrollY + rect.top - messageDiv.offsetHeight - 10}px`; // Position above form input with a 5px margin
                    messageDiv.style.left = `${rect.right - messageDiv.offsetWidth}px`; // Align right with the form input
                }
            }
    
            // Set initial position
            updateMessageBoxPosition();
    
            // Update position on window resize or scroll
            window.addEventListener("resize", updateMessageBoxPosition);
            window.addEventListener("scroll", updateMessageBoxPosition);
    
            // Auto-scroll to the end when content is edited
            messageDiv.addEventListener('input', function() {
                this.scrollLeft = this.scrollWidth;
            });
        }
    }
    

    // Function to toggle the display of the branding message
    function toggleBrandingMessage(displayStatus) {
        const brandingDiv = document.getElementById('branding_message');
        if (brandingDiv) {
            brandingDiv.style.display = displayStatus ? 'block' : 'none';
        }
    }

    function toggleMessageBox(displayStatus) {
        const messageBox = document.getElementById('message_box');
        if (messageBox) {
            messageBox.style.display = displayStatus ? 'block' : 'none';
        }
    }

    async function initializeBranding() {
        insertBrandingMessage();
        chrome.storage.local.get('branding_message', function(data) {
            const isDisplayed = data.branding_message !== 'off';
            toggleBrandingMessage(isDisplayed);
        });
        // Add a listener for changes in chrome.storage.local
        chrome.storage.onChanged.addListener(function(changes, namespace) {
            if ('branding_message' in changes) {
                const newValue = changes.branding_message.newValue;
                toggleBrandingMessage(newValue !== 'off');
            }
        });
    }

    async function initializeMessageBox() {
        insertMessageBox();
        chrome.storage.local.get('message_box', function(data) {
            const isDisplayed = data.branding_message !== 'off';
            toggleMessageBox(isDisplayed);
        });
        // Add a listener for changes in chrome.storage.local
        chrome.storage.onChanged.addListener(function(changes, namespace) {
            if ('message_box' in changes) {
                const newValue = changes.message_box.newValue;
                toggleMessageBox(newValue !== 'off');
            }
        });
    }

    async function getLeaderboardMode() {
        return new Promise(resolve => {
            chrome.storage.local.get(['leaderboard_mode'], function(result) {
                resolve(result.leaderboard_mode ? result.leaderboard_mode : 'on');
            });
        });
    }

    // Function to render the leaderboard
    async function renderLeaderboard(mode) {
        chrome.storage.local.get('leaderboard', async (result) => {
            const leaderboard = result.leaderboard;
            let leaderboardDiv = document.getElementById('leaderboard');

            if (!leaderboardDiv) {
                leaderboardDiv = document.createElement('div');
                leaderboardDiv.id = 'leaderboard';
                leaderboardDiv.style.position = 'fixed';
                leaderboardDiv.style.top = '640px';
                leaderboardDiv.style.left = '50%'; // Center horizontally
                leaderboardDiv.style.transform = 'translateX(-50%)'; // Adjust centering precisely
                leaderboardDiv.style.backgroundColor = 'white';
                leaderboardDiv.style.zIndex = '1000';
                leaderboardDiv.style.overflowY = 'auto';
                leaderboardDiv.style.width = "245px";
                leaderboardDiv.style.fontSize = "14px";
                leaderboardDiv.style.backgroundColor = "#fffbf5";
                leaderboardDiv.style.borderRadius = "5px";
                document.body.appendChild(leaderboardDiv);
            }

            // Clear current content
            leaderboardDiv.innerHTML = '';

            if (leaderboard && Object.keys(leaderboard).length > 0) {
                // Sort leaderboard by number of wins descending
                const sortedLeaderboard = Object.entries(leaderboard).sort((a, b) => b[1].wins - a[1].wins);
                console.log(sortedLeaderboard)
                
                var topFive; //change here
                if (mode === "play") {
                    topFive = sortedLeaderboard.slice(0,5)
                } else {
                    topFive = sortedLeaderboard
                }
                
                // Add each user to the leaderboard display
                topFive.forEach(([user, data]) => {
                    const userDiv = document.createElement('div');
                    userDiv.style.display = 'flex';
                    userDiv.style.alignItems = 'center';
                    userDiv.style.margin = '5px';
                    userDiv.style.justifyContent = "space-between";

                    const img = document.createElement('img');
                    img.src = data.photoUrl;
                    img.style.width = '32px';
                    img.style.height = '32px';
                    img.style.marginRight = '10px';

                    const nameSpan = document.createElement('span');
                    nameSpan.textContent = user;
                    nameSpan.style.textWrap = "nowrap";
                    nameSpan.style.overflow = "hidden";

                    const winsSpan = document.createElement('span');
                    winsSpan.textContent = ` Ws: ${data.wins}`;
                    winsSpan.style.marginLeft = '10px';
                    winsSpan.style.textWrap = "nowrap";
                    winsSpan.style.overflow = "visible";

                    userDiv.appendChild(img);
                    userDiv.appendChild(nameSpan);
                    userDiv.appendChild(winsSpan);
                    leaderboardDiv.appendChild(userDiv);
                });
            } else {
                leaderboardDiv.innerHTML = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No winners yet!';
            }

            let currentLeaderboardMode = await getLeaderboardMode()

            if (currentLeaderboardMode === "off") {
                document.getElementById("leaderboard").style.display = "none";
            } else if (currentLeaderboardMode === "on") {
                document.getElementById("leaderboard").style.display = "block";
            }
        });
    }

    function seeFullLeaderboard() {
        const mainElement = document.querySelector("main");
        Array.from(mainElement.children).forEach(child => {
            child.style.display = 'none'; // Set display to none
        });
        document.getElementById("branding_message").style.display = 'none';
        document.getElementById("message_box").style.display = 'none';
        document.getElementById("footer_message").style.display = 'none';

        document.getElementById("leaderboard").style.top = "150px";
        document.getElementById("leaderboard").style.marginTop = "0px";
        document.getElementById("leaderboard").style.height = "450px";
        document.getElementById("leaderboard").style.width = "300px";
        document.getElementById("leaderboard").style.backgroundColor = "rgb(255 251 245 / 53%)";
        document.getElementById("leaderboard").style.display = "block";
    }

    function setBackground() {
        chrome.storage.local.get('background', function(result) {
            if (result.background) {
                // Get the element with id 'root' and set the background
                var rootElement = document.getElementById('root');
                if (rootElement) {
                    rootElement.style.backgroundImage = `url(${result.background})`;
                    rootElement.style.backgroundPosition = "center";
                    rootElement.style.backgroundSize = "cover"; 
                    rootElement.style.backgroundAttachment = "fixed"
                }
            }
        });
    }

    function removeRowOuterBar() {
        const style = document.createElement('style');
        // Add your custom CSS to override the .outer-bar class
        style.innerHTML = `
            .outer-bar {
                background-color: transparent !important;  /* Example change */
            }
        `;
        document.head.appendChild(style);
    }

    // Function to add or update a winner on the leaderboard
    function addWinner(username, profilePhotoUrl) {
        chrome.storage.local.get('leaderboard', (result) => {
            let leaderboard = result.leaderboard || {};

            // Update or add new winner
            if (leaderboard[username]) {
                leaderboard[username].wins += 1;
            } else {
                leaderboard[username] = { wins: 1, photoUrl: profilePhotoUrl };
            }

            // Save updated leaderboard back to local storage
            chrome.storage.local.set({leaderboard}, () => {
                console.log('Leaderboard updated!');
                renderLeaderboard("play");
            });
        });
    }

    // Function to add or update a winner on the gifterboard
    // function addGifter(username, profilePhotoUrl, giftTotal) {
    //     chrome.storage.local.get('gifterboard', (result) => {
    //         let gifterboard = result.gifterboard || {};

    //         // Update or add new winner
    //         if (gifterboard[username]) {
    //             gifterboard[username].wins += giftTotal;
    //         } else {
    //             gifterboard[username] = { wins: giftTotal, photoUrl: profilePhotoUrl };
    //         }

    //         // Save updated gifterboard back to local storage
    //         chrome.storage.local.set({gifterboard: gifterboard}, () => {
    //             console.log('Gifterboard updated!');
    //             renderGifterboard();
    //         });
    //     });
    // }

    function addComment(commentData) {
        const commentColumn = document.getElementById('commentColumn') || createCommentColumn();
        if (document.querySelector('.comment-column')) {
            document.querySelector('.comment-column').style.display = "block";
        }

        // Prevent duplicate comments
        if (isDuplicateComment(commentData)) {
            console.log('Duplicate comment detected, not adding to the column.');
            return;
        }

        // Create card elements
        const card = createCommentCard(commentData);
        commentColumn.appendChild(card);

        // Limit comments to 20
        if (commentColumn.children.length > 20) {
            commentColumn.removeChild(commentColumn.firstChild);
        }

        // Keep the scroll at the bottom
        commentColumn.scrollTop = commentColumn.scrollHeight;
    }

    function createCommentColumn() {
        const commentColumn = document.createElement('div');
        commentColumn.id = 'commentColumn';
        commentColumn.className = 'comment-column';
        document.body.appendChild(commentColumn);
        return commentColumn;
    }

    function createCommentCard(commentData) {
        const card = document.createElement('div');
        card.className = 'comment-card';

        const profilePhoto = document.createElement('img');
        profilePhoto.src = commentData.profilePhotoUrl;
        profilePhoto.alt = 'Profile Photo';
        profilePhoto.onerror = function() {
            this.src = 'path_to_default_image.jpg'; // Provide your default image path
        };

        const contentDiv = document.createElement('div');
        contentDiv.className = 'content';

        const nickname = document.createElement('div');
        nickname.className = 'nickname';
        nickname.textContent = commentData.nickname;

        const commentText = document.createElement('div');
        commentText.className = 'comment';
        commentText.textContent = commentData.comment;

        // Append elements to card
        contentDiv.appendChild(nickname);
        contentDiv.appendChild(commentText);
        card.appendChild(profilePhoto);
        card.appendChild(contentDiv);

        // Add event listener to the card
        card.addEventListener('click', function() {
            typeCommentFromColumn({
                nickname: commentData.nickname,
                comment: commentData.comment,
                profilePhotoUrl: commentData.profilePhotoUrl // Including profile photo URL
            });
        });

        return card;
    }

    async function typeCommentFromColumn(data) {
        guessWord(data.comment.split(" ")[0]);
        addUserOnComment(data.nickname, data.profilePhotoUrl);
        if (data.comment.split(" ")[0].toLowerCase() === currentAnswer.toLowerCase()) {
            await sPause(3000);
            showWinnerCard(data.nickname, data.profilePhotoUrl);
            await addGameNumber(currentGame);
            await sPause(7000);
            starting = true;
        }
    }

    function isDuplicateComment(newCommentData) {
        const comments = document.querySelectorAll('.comment-card');
        return Array.from(comments).some(comment => {
            const nickname = comment.querySelector('.nickname').textContent;
            const commentText = comment.querySelector('.comment').textContent;
            return nickname === newCommentData.nickname && commentText === newCommentData.comment;
        });
    }

    // Add styles when the content script loads
    function addStyles() {
        const css = `
            .comment-column {
                position: fixed;
                left: 0;
                top: 0;
                width: 250px;
                height: 100%;
                overflow-y: auto;
                background-color: #f4f4f4;
            }

            .comment-card {
                display: flex;
                align-items: center;
                padding: 10px;
                margin: 10px;
                background-color: white;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }

            .comment-card img {
                width: 50px;
                height: 50px;
                border-radius: 50%;
                margin-right: 10px;
            }

            .comment-card .content {
                flex-grow: 1;
            }

            .comment-card .nickname {
                font-weight: bold;
            }

            .comment-card .comment {
                font-size: 0.8rem;
                color: #333;
            }
        `;

        const styleSheet = document.createElement('style');
        styleSheet.type = 'text/css';
        styleSheet.innerText = css;
        document.head.appendChild(styleSheet);
    }

    addStyles();

    function guessWord(guess) {
        const input = document.querySelector('.word');
        if (input) {
            // Set the new value
            const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
            nativeInputValueSetter.call(input, guess);
        
            // Create a new event for React
            const inputEvent = new Event('input', { bubbles: true });
            input.dispatchEvent(inputEvent);
        
            // Optionally, create and dispatch a 'change' event if 'input' is not sufficient
            const changeEvent = new Event('change', { bubbles: true });
            input.dispatchEvent(changeEvent);
        
            if (input.form) {
                // Create and dispatch the submit event
                const submitEvent = new Event('submit', { bubbles: true, cancelable: true });
                input.form.dispatchEvent(submitEvent);
            } 
        } else {
            console.error("Input element with class 'word' not found.");
        }
    }

    function hideGameNumber() {
        document.querySelector(".info-bar").querySelector(".label").nextElementSibling.innerText = "#";
    }

    function getGameNumber() {
        var gameNumber = document.querySelector(".info-bar").querySelector(".label").nextElementSibling.innerText;
        return gameNumber.replace("#","");
    }

    async function setGameNumber() {
        currentGame = getGameNumber();
        currentAnswer = await fetchWinning(currentGame);
    }

    function storeGameNumber() {
        let gameNumber = getGameNumber();
        chrome.storage.local.set({'gameNumber': gameNumber}, function() {
            console.log('Game number stored:', gameNumber);
        });
    }

    function sendGameNumber() {
        let gameNumber = getGameNumber();
        chrome.runtime.sendMessage({gameNumber: gameNumber});
    }

    async function prepareGame() {
        try {
            const result = await chrome.storage.local.get('user_email');
            const userEmail = result.user_email;
            const url = endpoint + `/test-status?email=${encodeURIComponent(userEmail)}`;

            const response = await fetch(url);
            const data = await response.json();

            console.log('Subscription status:', data.sub_status);
            return data.sub_status; // Now this value can be used in a thenable manner or further awaited
        } catch (error) {
            console.error('Error fetching subscription status:', error);
            return false; // Optionally return false or undefined in case of error
        }
    }

    async function startNewGame() {
        // Simulate a button click on an element with class '.btn'
        const button = document.querySelector('.btn');
        if (button) {
            button.click();
        }

        // Wait for 2000 milliseconds before executing the next steps
        setTimeout(async () => {
            // Click the fourth item in a list of elements with the class '.menu-item'
            const menuItem = document.querySelectorAll('.menu-item')[3];
            if (menuItem) {
                menuItem.click();
            }
            await sPause(1000);
            // Adjust the style properties of an element with the class '.modal'
            const modal = document.querySelector('.modal');
            if (modal) {
                modal.style.width = "200px";
                modal.style.marginLeft = "256px";
            }

            // Generate a random number between 0 and the number of .game-selection-button elements
            const nodeList = document.querySelectorAll('.game-selection-button');
            const elementArray = Array.from(nodeList);
            var gameButtons = elementArray.reverse();
            gameButtons.pop();
            var randomIndex = Math.floor(Math.random() * gameButtons.length).toString();

            //both are arrays of strings
            var playedGames = await getPlayedGameNumbers();
            var blockedGames = await getBlockedGameNumbers();

            while (playedGames.includes(randomIndex) || blockedGames.includes(randomIndex)) {
                randomIndex = Math.floor(Math.random() * gameButtons.length).toString();
            }

            if (gameButtons[Number(randomIndex)]) {
                gameButtons[Number(randomIndex)].click();
            }

            await sPause(1000)
            setGameNumber();
            sendGameNumber();
            hideGameNumber();

        }, 1000);
    }

    //takes string
    async function fetchHints(gameId, numWords) {
        const url = endpoint + `/hints/${gameId}`;

        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            const data = await response.json();
            console.log('Game data retrieved:', data);

            return data.answers.slice(0, numWords);  // Return only the desired number of words
        } catch (error) {
            console.error('Failed to fetch game:', error);
        }
    }

    async function fetchWinning(gameId) {
        try {
            const url = endpoint + `/winning/${gameId}`;
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Failed to fetch game winning word for the game');
            }
            const data = await response.json();
            console.log('Game data retrieved:', data);
            // Here you can update the DOM or perform other actions with the fetched data
            chrome.runtime.sendMessage({gameAnswer: data.answer});
            return data.answer;
        } catch (error) {
            console.log('Error getting winning word');
        }
    }

    async function fetchLatestComment() {
        try {
            const url = endpoint + `/comments/latest?host=${loggedInUser}`;
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Failed to fetch the latest comment');
            }
            const comment = await response.json();
            if (await getGameMode() === "manual") {
                addComment({
                    profilePhotoUrl: comment.profilePhotoUrl,
                    nickname: comment.nickname,
                    comment: comment.comment
                });
            }
            // Here you can update the DOM or perform other actions with the fetched comment
            return comment;
        } catch (error) {
            console.log('Error checking for latest comment');
        }
    }

    async function fetchLatestCommentGroup() {
        try {
            const url = endpoint + `/allcomments/latest?host=${loggedInUser}`;
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Failed to fetch the latest comments');
            }
            const comments = await response.json();
            
            console.log('Latest Comments:', comments);
            // Here you can update the DOM or perform other actions with the fetched comments
            return comments;
        } catch (error) {
            console.error('Error:', error.message);
        }
    }

    async function fetchLatestGifts() {
        try {
            const url = endpoint + `/gifts/latest?host=${loggedInUser}`;
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Failed to fetch the latest gifts');
            }
            const gifts = await response.json();
            
            console.log('Latest Gifts:', gifts);
            // Here you can update the DOM or perform other actions with the fetched gifts
            return gifts;
        } catch (error) {
            console.error('Error:', error.message);
        }
    }

    async function checkForWinner() {
        try {
            console.log(currentAnswer);
            console.log(loggedInUser);
            console.log(currentGame);
            const url = endpoint + `/comments/winner?host=${loggedInUser}&comment=${currentAnswer}`;
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Failed to fetch the latest comment');
            }
            const comment = await response.json();
            if (await getGameMode() === "manual") {
                addComment({
                    profilePhotoUrl: comment.profilePhotoUrl,
                    nickname: comment.nickname,
                    comment: comment.comment
                });
            }
            // Here you can update the DOM or perform other actions with the fetched comment
            return comment;
        } catch (error) {
            console.log('Error checking for winner');
        }
    }

    // async function placeHints() {
    //     var gameId = Number(currentGame);
    //     const numWords = 2;
    //     var words = await fetchHints(gameId, numWords);
    //     for (var i = 0; i < 2; i++) {
    //         guessWord(words[i]);
    //         await sPause(1500);
    //     }
    //     await sPause(1000);
    //     coverInitialHints();
    // }

    function showWinnerCard(username, imageUrl) {
        var audio = new Audio(sounds["victory"]);
        audio.play();
        // Create the card overlay
        var card = document.createElement('div');
        card.style.position = 'fixed';
        card.style.top = '50%';
        card.style.left = '50%';
        card.style.transform = 'translate(-50%, -50%)';
        card.style.width = '400px'; // Updated width
        card.style.backgroundColor = 'white';
        card.style.boxShadow = '0 4px 8px rgba(0,0,0,0.1)';
        card.style.textAlign = 'center';
        card.style.borderRadius = '10px';
        card.style.padding = '20px';
        card.style.zIndex = '1000'; // Ensure it is on top
        card.style.overflowWrap = 'break-word'; // Ensures text wraps within the card

        // Create the title text
        var title = document.createElement('h2'); // Changed to h2 as requested
        title.textContent = username + " wins with '" + currentAnswer + "'";
        title.style.marginTop = '0';
        title.style.color = '#333';

        // Create the image element
        var img = document.createElement('img');
        img.src = imageUrl;
        img.alt = username + "'s profile picture";
        img.style.width = '100%'; // Make image responsive within the card
        img.style.height = 'auto';
        img.style.borderRadius = '5px'; // Optional: style as needed

        // Create the footer text
        var footerText = document.createElement('p');
        footerText.textContent = "New game starting...";
        footerText.style.color = '#666';
        footerText.style.fontSize = '16px';
        footerText.style.marginTop = '15px';

        // Append all elements to the card
        card.appendChild(title);
        card.appendChild(img);
        card.appendChild(footerText);

        // Append the card to the body of the document
        document.body.appendChild(card);

        addWinner(username, imageUrl);

        // Optionally, remove the card after some time or on click
        setTimeout(() => {
            document.body.removeChild(card);
        }, 5000); // Adjust time as necessary or remove for permanent display
    }

    function showLoadingOverlay() {

        if (loadingInterval) {
            clearInterval(loadingInterval);
        }

        // Create the overlay div
        var overlay = document.createElement('div');
        overlay.id = "start_overlay";
        overlay.style.position = 'fixed';
        overlay.style.top = '40px';
        overlay.style.left = '50%';
        overlay.style.transform = 'translate(-50%)';
        overlay.style.width = '700px'; // Adjust width as needed
        overlay.style.height = '500px';
        overlay.style.backgroundColor = 'rgba(0,0,0)';
        overlay.style.color = 'white';
        overlay.style.textAlign = 'center';
        overlay.style.borderRadius = '10px';
        overlay.style.padding = '20px';
        overlay.style.zIndex = '1000'; // Ensure it is on top
        overlay.style.fontSize = '36px'; // Larger text for better visibility

        // Create the text element
        var loadingText = document.createElement('p');
        loadingText.textContent = 'Game loading';
        loadingText.style.margin = '0';
        loadingText.style.marginTop = "40px";
        overlay.appendChild(loadingText);

        var loadingText2 = document.createElement('p');
        loadingText2.textContent = 'Game loading';
        loadingText2.style.margin = 'auto';
        loadingText2.style.marginTop = "40px";
        loadingText2.style.width = "400px"
        loadingText2.style.textAlign = "center";
        overlay.appendChild(loadingText2)

        // Append the overlay to the body of the document
        document.body.appendChild(overlay);
        //<span style='font-size: 25px;'>🍩</span> = <span style='font-size: 25px;'>✅</span><br>
        loadingText2.innerHTML = "<u>HOW'S IT WORK?</u>" + 
        //"<br>Host this live with <br><span style='background-color:white;color:black;border-radius:5px;font-size:24px;'>RunChatCapture.com</span>";
        "<br><span style='background-color:white;color:black;border-radius:5px;font-size:24px;'>RunChatCapture.com</span><br><span><span>Words with lower numbers are closer to the secret word!</span>";

        // Cycle through different loading text
        var dots = 0;
        var displayedAnswer = currentAnswer;
        loadingInterval = setInterval(() => {
            dots = (dots + 1) % 4;
            if (displayedAnswer !== "") {
                loadingText.innerHTML = "Game loading" + ".".repeat(dots) + 
                "<span style='display:block;'>Last game's word: " + displayedAnswer + "</span>";
            } else {
                loadingText.textContent = "Game loading" + ".".repeat(dots);
            }

        }, 500); // Update every 500 milliseconds

        // Function to remove the overlay
        // function removeOverlay() {
        //     clearInterval(loadingInterval);
        //     document.body.removeChild(overlay);
        // }

        // Optionally, call removeOverlay at some point to hide the loading screen
        // For example, remove after 10 seconds (for demonstration)
        // setTimeout(removeOverlay, 9000);
    }

    function addUserOnComment(username, imageUrl) {
        setTimeout(() => {
            var messages = document.querySelectorAll(".message");
            if (messages.length > 0 && messages[0].querySelector(".current")) {
                var currentUser = messages[0].querySelector(".current");
                var guessHistory = document.querySelectorAll(".guess-history")[0].querySelector(".current");

                // Function to create a container span
                function createUserContainer(username, imageUrl) {
                    var containerSpan = document.createElement('span');
                    containerSpan.style.display = 'flex';
                    containerSpan.style.alignItems = 'center'; // Ensure vertical alignment
                    containerSpan.style.marginLeft = '10px'; // Optional: space from previous content

                    var img = document.createElement('img');
                    img.src = imageUrl;
                    img.alt = username + "'s profile picture";
                    img.style.width = '37px';
                    img.style.height = '37px';

                    var usernameSpan = document.createElement('span');
                    
                    if (donutUsers.includes(username)) {
                        usernameSpan.innerHTML = username + "<span style='font-size: 25px;'>✅</span>";
                    } else {
                        usernameSpan.textContent = username;
                    }
                    console.log('donutUsers')
                    console.log(donutUsers)

                    usernameSpan.style.marginLeft = '5px'; // Space between image and username

                    containerSpan.appendChild(img);
                    containerSpan.appendChild(usernameSpan);

                    return containerSpan;
                }

                // Insert the container span for current user
                var rowCurrentUser = currentUser.querySelector(".row").firstChild;
                var containerSpanCurrentUser = createUserContainer(username, imageUrl);
                rowCurrentUser.parentNode.insertBefore(containerSpanCurrentUser, rowCurrentUser.nextSibling);

                // Insert the container span for guess history
                var rowGuessHistory = guessHistory.querySelector(".row").firstChild;
                var containerSpanGuessHistory = createUserContainer(username, imageUrl);
                rowGuessHistory.parentNode.insertBefore(containerSpanGuessHistory, rowGuessHistory.nextSibling);
            }
        }, 300);
    }

    async function playSound() {
        let giftValue = await getHintGift();

        if (giftValue === "rose") {
            // var audio = new Audio(sounds["rose"]);
            // audio.play();
        }
        if (giftValue === "finger_heart") {
            // var audio = new Audio(sounds["finger_heart"]);
            // audio.play();
        }
        if (giftValue === "tiny_diny") {
            // var audio = new Audio(sounds["tiny_diny"]);
            // audio.play();
        }
        if (giftValue === "donut") {
            // var audio = new Audio(sounds["donut"]);
            // audio.play();
        }
    }

    function addUserOnUncoverHint(username, imageUrl) {
        // Function to create a container span
        function createUserContainer(username, imageUrl) {
            var containerSpan = document.createElement('span');
            containerSpan.style.display = 'flex';
            containerSpan.style.alignItems = 'center'; // Ensure vertical alignment
            containerSpan.style.marginLeft = '10px'; // Optional: space from previous content

            var img = document.createElement('img');
            img.src = imageUrl;
            img.alt = username + "'s profile picture";
            img.style.width = '37px';
            img.style.height = '37px';

            var usernameSpan = document.createElement('span');
            usernameSpan.textContent = username;
            usernameSpan.style.marginLeft = '5px'; // Space between image and username

            containerSpan.appendChild(img);
            containerSpan.appendChild(usernameSpan);

            return containerSpan;
        }

        // Insert the container span for current user
        var rowBeforeCoverFirstChild = document.querySelectorAll(".cover")[document.querySelectorAll(".cover").length - 1].previousElementSibling.firstChild;
        var containerSpan = createUserContainer(username, imageUrl);
        rowBeforeCoverFirstChild.parentNode.insertBefore(containerSpan, rowBeforeCoverFirstChild.nextSibling);
    }

    // async function coverInitialHints() {
    //     let activeGift = "";
    //     let giftValue = await getHintGift();

    //     let giftMap = {
    //         tinyDiny: "Tiny Diny &#129430;",
    //         fingerHeart: 'Finger Heart <span style="color:red">&#10084;</span>',
    //         rose: "Rose &#x1F339;",
    //         donut: "Donut &#127849;"
    //     };

    //     if (giftValue === "rose") {
    //         activeGift = giftMap.rose;
    //     }
    //     if (giftValue === "finger_heart") {
    //         activeGift = giftMap.fingerHeart;
    //     }
    //     if (giftValue === "tiny_diny") {
    //         activeGift = giftMap.tinyDiny;
    //     }
    //     if (giftValue === "donut") {
    //         activeGift = giftMap.donut;
    //     }

    //     for (var i = 0; i < 3; i++) {
    //         const targetDiv = document.querySelectorAll(".row-wrapper")[i];

    //         // Create a cover div
    //         const coverDiv = document.createElement('div');
    //         coverDiv.classList.add("cover");
    //         coverDiv.style.position = 'absolute';
    //         coverDiv.style.top = '0';
    //         coverDiv.style.left = '0';
    //         coverDiv.style.width = '85%';
    //         coverDiv.style.height = '100%';
    //         coverDiv.style.backgroundColor = 'rgba(0, 0, 0)';
    //         coverDiv.style.color = "white";
    //         coverDiv.style.paddingLeft = "10px";
    //         coverDiv.style.paddingTop = "3px";

    //         // Create a text element
    //         const textElement = document.createElement('p');
    //         textElement.innerHTML = activeGift + ' for hint';

    //         // Add the text element to the cover div
    //         coverDiv.appendChild(textElement);

    //         // Add the cover div to the target div
    //         targetDiv.appendChild(coverDiv);
    //     }
    // }

    async function executeGifts(gifts) {
        let activeGift = "";
        let currEndGift = "";
        let giftValue = await getHintGift();
        let endValue = await getEndGift();
        if (giftValue === "no_gift") {
            return "gifts_executed";
        }

        let giftMap = {
            tinyDiny: "https://p16-webcast.tiktokcdn.com/img/maliva/webcast-va/3851a489dea62b3a9fe99f61de5470ae~tplv-obj.png",
            fingerHeart: "https://p16-webcast.tiktokcdn.com/img/maliva/webcast-va/a4c4dc437fd3a6632aba149769491f49.png~tplv-obj.png",
            rose: "https://p16-webcast.tiktokcdn.com/img/maliva/webcast-va/eba3a9bb85c33e017f3648eaf88d7189~tplv-obj.png",
            donut: "https://p16-webcast.tiktokcdn.com/img/maliva/webcast-va/4e7ad6bdf0a1d860c538f38026d4e812~tplv-obj.png"
        };

        if (giftValue === "rose") {
            activeGift = giftMap.rose;
        }
        if (giftValue === "finger_heart") {
            activeGift = giftMap.fingerHeart;
        }
        if (giftValue === "tiny_diny") {
            activeGift = giftMap.tinyDiny;
        }
        if (giftValue === "donut") {
            activeGift = giftMap.donut;
        }

        for (var i = 0; i < gifts.length; i++) {
            if (giftMap.donut === gifts[i].giftImage.toString()) {
                donutUsers.push(gifts[i].nickname)
                console.log('donutUsers')
                console.log(donutUsers)
            }
        }

        if (endValue === "corgie") {
            currEndGift = endGifts.corgie;
        }
        if (endValue === "forever_rosa") {
            currEndGift = endGifts.forever_rosa;
        }
        if (endValue === "money_gun") {
            currEndGift = endGifts.money_gun;
        }

        //check if an end gift has been provided
        for (var i = 0; i < gifts.length; i++) {
            if (gifts[i].giftImage.toString() === currEndGift) {
                executingGifts = false;
                return {"nickname": gifts[i].nickname, "profilePhotoUrl": gifts[i].profilePhotoUrl, "comment": currentAnswer}
            }
        }

        //execute hints
        for (var i = 0; i < gifts.length; i++) {
            if (gifts[i].giftImage.toString() === activeGift) {
                try{
                    var giftTotal = Number(gifts[i].giftTotal);
                    for (var j = 0; j < giftTotal; j++) {
                        document.querySelector('.btn').click();
                        await sPause(500);
                        document.querySelector(".dropdown").querySelectorAll("button")[1].click()
                        addUserOnComment(gifts[i].nickname, gifts[i].profilePhotoUrl);
                        await sPause(500);
                    }
                    startEffect(gifts[i].profilePhotoUrl);
                } catch(e) {
                    console.log(e);
                }
                playSound();
            }
        }
        executingGifts = false;
        return "gifts_executed"
    }

    async function isGameActive() {
        return new Promise(resolve => {
            chrome.storage.local.get(['gameActive'], function(result) {
                // Ensure the result is always boolean by using !! operator
                resolve(!!result.gameActive);
            });
        });
    }

    async function getPlayedGameNumbers() {
        return new Promise((resolve, reject) => {
            chrome.storage.local.get(['gameNumbers'], function(result) {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve(result.gameNumbers || []);
                }
            });
        });
    }

    async function getHintGift() {
        return new Promise(resolve => {
            chrome.storage.local.get(['hint_gift'], function(result) {
                console.log(result);
                // If hint_gift is found in the storage, return it, otherwise default to 'tiny_diny'
                resolve(result.hint_gift ? result.hint_gift : 'tiny_diny');
            });
        });
    }

    async function getEndGift() {
        return new Promise(resolve => {
            chrome.storage.local.get(['end_gift'], function(result) {
                console.log(result);
                // Return end_gift from storage or default to corgie'
                resolve(result.end_gift ? result.end_gift : 'corgie');
            });
        });
    }

    async function getGameMode() {
        return new Promise(resolve => {
            chrome.storage.local.get(['game_mode'], function(result) {
                resolve(result.game_mode ? result.game_mode : 'automated');
            });
        });
    }

    async function getBlockedGameNumbers() {
        return new Promise((resolve, reject) => {
            chrome.storage.sync.get(['blockedGameNumbers'], function(result) {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve(result.blockedGameNumbers || []);
                }
            });
        });
    }

    async function addGameNumber(gameNumber) {
        return new Promise((resolve, reject) => {
            chrome.storage.local.get(['gameNumbers'], function(result) {
                let gameNumbers = result.gameNumbers || [];
                gameNumbers.push(gameNumber); // Directly add the new game number
                console.log(gameNumbers);
                chrome.storage.local.set({gameNumbers: gameNumbers}, () => {
                    if (chrome.runtime.lastError) {
                        reject(chrome.runtime.lastError);
                    } else {
                        resolve();
                    }
                });
            });
        });
    }

    function insertFooterMessage() {
        const leaderboard = document.getElementById("leaderboard");
    
        if (leaderboard && !document.getElementById("footer_message")) {
            const footerDiv = document.createElement('div');
            footerDiv.id = 'footer_message';
            footerDiv.style.position = 'absolute';
            footerDiv.style.backgroundColor = 'rgb(255, 251, 245)';
            footerDiv.style.borderRadius = '5px';
            footerDiv.style.padding = '2px 20px 0px 20px';
            footerDiv.style.textAlign = 'center';
            footerDiv.style.width = 'fit-content';
            footerDiv.style.zIndex = '10';
    
            // Text message in the div
            const messageText = document.createElement('span');
            messageText.innerText = "RunChatCapture.com";
    
            // Toggle button below the message text
            const toggleButton = document.createElement('span');
            toggleButton.innerText = "✖️"; // "X" character initially
            toggleButton.style.display = "block";
            toggleButton.style.cursor = "pointer";
            toggleButton.style.fontSize = "14px";
    
            // Toggle functionality
            toggleButton.addEventListener("click", () => {
                if (messageText.style.display === "none") {
                    messageText.style.display = "inline";
                    toggleButton.innerText = "✖️"; // Change to "X"
                } else {
                    messageText.style.display = "none";
                    toggleButton.innerText = "➕"; // Change to "+"
                }
            });
    
            // Append text and toggle to footer div
            footerDiv.appendChild(messageText);
            footerDiv.appendChild(toggleButton);
    
            // Position 200px below the leaderboard and center
            function updateFooterPosition() {
                const rect = leaderboard.getBoundingClientRect();
                console.log("Leaderboard: "+rect.top.toString())
                if (rect.top > 0) {
                    footerDiv.style.top = `${window.scrollY + rect.top + 200}px`; // 200px below the leaderboard
                    footerDiv.style.left = '50%';
                    footerDiv.style.transform = 'translateX(-50%)'; // Center horizontally
                } else {
                    footerDiv.style.top = `90%`;
                    footerDiv.style.left = '50%';
                    footerDiv.style.transform = 'translateX(-50%)'; // Center horizontally
                }

            }
    
            // Set initial position and append to the body
            updateFooterPosition();
            document.body.appendChild(footerDiv);
    
            // Reposition on window resize or scroll
            window.addEventListener("resize", updateFooterPosition);
            window.addEventListener("scroll", updateFooterPosition);
        }
    }
     

    function addDraggableInput() {
        if (document.getElementById("draggableInput")) {
            return;
        }
    
        // Select the main and target input elements
        const mainElement = document.querySelector('main');
        const targetInput = document.querySelector('main form input');
      
        if (mainElement && targetInput) {
          // Get the bounding rectangle of the target input
          const rect = targetInput.getBoundingClientRect();
      
          // Calculate the position for the draggable input relative to `main`
          const initialTop = rect.top + (rect.height / 2) - 24; // Center vertically adjusted with -24
          const initialLeft = rect.right - 200; // Align to the far right edge minus the width of the draggable input
      
          // Create the draggable container span
          const draggableInput = document.createElement("span");
          draggableInput.id = "draggableInput"
          draggableInput.style.width = "200px";
          draggableInput.style.display = "flex";
          draggableInput.style.alignItems = "center";
          draggableInput.style.padding = "5px";
          draggableInput.style.backgroundColor = "white"; // White background
          draggableInput.style.border = "1px solid black"; // Black border
          draggableInput.style.borderRadius = "5px";
          draggableInput.style.cursor = "move";
          draggableInput.style.position = "absolute";
          draggableInput.style.top = `${initialTop}px`;
          draggableInput.style.left = `${initialLeft}px`;
          draggableInput.className = "draggable-input";
      
          // Add an image element inside the span
          const img = document.createElement("img");
          img.id = "profileImageId"
          img.src = loggedInProfileImage;
          img.style.width = "37px";
          img.style.height = "37px";
          img.style.marginRight = "10px";
      
          // Add an input element inside the span
          const input = document.createElement("input");
          input.type = "text";
          input.placeholder = "Host guesses";
          input.style.flex = "1";
          input.style.border = "none";
          input.style.outline = "none";
          input.style.fontSize = "1.25em";
          input.style.maxWidth = "calc(100% - 47px)"; // Ensures the input stays within the span width
      
          // Event listener for Enter key
          input.addEventListener("keypress", async (event) => {
            if (event.key === "Enter") {

                const details = {
                    host: loggedInUser,
                    nickname: loggedInUser,
                    comment: input.value,
                    profilePhotoUrl: loggedInProfileImage,
                    checked: "no"
                };
                
                try {
                    await fetch(endpoint + '/comments', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(details)
                    });
                } catch (error) {
                    console.error('Failed to post details:', error);
                }
      
                // Clear the input field
                input.value = "";
            }
          });

          // Append image and input to the draggable container
          draggableInput.appendChild(img);
          draggableInput.appendChild(input);

          const toggleButton = document.createElement("button");
          toggleButton.innerHTML = "✖️"; // Cross character initially
          toggleButton.style.position = "absolute";
          toggleButton.style.fontSize = "12px"; // Set font size to 12px
          toggleButton.style.border = "none";
          toggleButton.style.background = "none";
          toggleButton.style.cursor = "pointer";
          toggleButton.style.zIndex = "10"; // Ensure it stays visible
          
          // Function to update the position of the toggle button
          function updateTogglePosition() {
            const rect = targetInput.getBoundingClientRect();
            const initialTop = rect.top + (rect.height / 2) - 24; // Adjusted top position
            const initialLeft = rect.right - 200; // Adjusted left position
          
            // Position toggle button relative to input container
            toggleButton.style.top = `${initialTop}px`;
            toggleButton.style.left = `${initialLeft + 180}px`;
          }
          
          // Initial positioning of the toggle button
          updateTogglePosition();
          
          // Add click event for toggle button
          toggleButton.addEventListener("click", () => {
            if (draggableInput.style.display === "none") {
              // Show the container and switch to "✖️"
              draggableInput.style.display = "flex";
              toggleButton.innerHTML = "✖️"; // Cross
            } else {
              // Hide the container and switch to "➕"
              draggableInput.style.display = "none";
              toggleButton.innerHTML = "➕"; // Plus
            }
          });
          
          // Append the toggle button to `main`
          mainElement.appendChild(toggleButton);
          mainElement.appendChild(draggableInput);
      
          // Function to reposition the element on resize
          function updatePosition() {
            const rect = targetInput.getBoundingClientRect();
            draggableInput.style.top = `${rect.top + (rect.height / 2) - 24}px`;
            draggableInput.style.left = `${rect.right - 200}px`;
          }
      
          // Update position on window resize
          window.addEventListener("resize", updatePosition);
          window.addEventListener("resize", updateTogglePosition);
      
        //   // WILL TEST DRAGGABILITY MORE BEFORE RELEASE
        //   let offsetX, offsetY;
      
        //   draggableInput.addEventListener("mousedown", (e) => {
        //     offsetX = e.clientX - draggableInput.offsetLeft;
        //     offsetY = e.clientY - draggableInput.offsetTop;
      
        //     function moveElement(e) {
        //       draggableInput.style.left = e.clientX - offsetX + "px";
        //       draggableInput.style.top = e.clientY - offsetY + "px";
        //     }
      
        //     function stopDragging() {
        //       document.removeEventListener("mousemove", moveElement);
        //       document.removeEventListener("mouseup", stopDragging);
        //     }
      
        //     document.addEventListener("mousemove", moveElement);
        //     document.addEventListener("mouseup", stopDragging);
        //   });
        } else {
          console.error("Main element or target input not found.");
        }
      }
      

    async function startGame() {
        var gameOn = true;
        var count = 0;
        starting = true;
        if (loggedInUser === "") {
            alert("Add a username to start contexto");
            return;
        }

        var proceed = await prepareGame();
        if (!proceed) {
            alert("Server is down or your subscription is not active. You can not start a game. If you believe this is an error, contact the developers.");
            return;
        }

        chrome.storage.local.set({'gameActive': true});
        await chrome.storage.local.get("photoUrl", function(result) {
            if (result.photoUrl) {
                console.log("Retrieved profile photo: " + result.photoUrl);
                loggedInProfileImage = result.photoUrl;
                document.getElementById("profileImageId").src = result.photoUrl;
            } else {
                alert("Add a profile photo to display for your audience when you guess on screen")
            }
        })

        document.querySelector("h1").innerText = "TYPE TO PLAY!"
        document.querySelector(".top-ad-padding").style.paddingTop = "115px";

        initializeMessageBox();
        initializeBranding();
        renderLeaderboard("play");
        setBackground();
        removeRowOuterBar();
        addDraggableInput();

        while (gameOn === true) {
            // Check if the game should be active
            let isActive = await isGameActive();
            if (!isActive) {
                console.log("Game stopped by user.");
                break;
            }
            
            document.querySelector(".top-ad-padding").style.paddingTop = "115px";
            insertFooterMessage();

            try {
                if (starting === true) {


                    showLoadingOverlay();
                    count = 0;
                    injectCSS();
                    while (starting === true) {
                        startNewGame();
                        await sPause(4000);
                        if (document.querySelector(".end-msg")) {//TEST
                            continue;
                        }
                        clearInterval(loadingInterval);
                        document.body.removeChild(document.getElementById("start_overlay"));
                        starting = false;
                    }
                }
                if (document.querySelector(".end-msg")) {//TEST Fix this
                    starting = true;
                    continue;
                }
                var giftResult = "";
                if (executingGifts === false) {
                    var gifts = await fetchLatestGifts();
                    if (gifts.length > 0) {
                        executingGifts = true;
                        giftResult = await executeGifts(gifts);
                    }
                }
                var gameMode = await getGameMode();
                var winningComment = await checkForWinner();

                //check if the game ending gift was given
                if (typeof giftResult === "object") {
                    winningComment = giftResult;
                }

                if (winningComment && gameMode === "automated" && count > 59) {
                    // var audio = new Audio(sounds["tick"]);
                    // audio.play();

                    if (document.querySelector('.comment-column')) {
                        document.querySelector('.comment-column').style.display = "none";
                    }
                    guessWord(winningComment.comment.split(" ")[0]);
                    addUserOnComment(winningComment.nickname, winningComment.profilePhotoUrl);
                    await sPause(3000);
                    startEffect(winningComment.profilePhotoUrl);
                    showWinnerCard(winningComment.nickname, winningComment.profilePhotoUrl);
                    guessedWords = [];
                    await addGameNumber(currentGame);
                    await sPause(6000);
                    starting = true;
                    continue;
                } 
                var comments = await fetchLatestCommentGroup();

                if (Array.isArray(comments) && comments.length > 0) {
                    for (let recentComment of comments) {

                        if (guessedWords.includes(recentComment.comment.split(" ")[0].toLowerCase())) {
                            continue;
                        }
                        guessedWords.push(recentComment.comment.split(" ")[0].toLowerCase());

                        if (recentComment && gameMode === "automated") {
                            // var audio = new Audio(sounds["tick"]);
                            // audio.play();

                            if (document.querySelector('.comment-column')) {
                                document.querySelector('.comment-column').style.display = "none";
                            }

                            guessWord(recentComment.comment.split(" ")[0]);

                            // if (count % 10 === 0) {
                            //     speakText(recentComment.comment.split(" ")[0]);
                            // }

                            addUserOnComment(recentComment.nickname, recentComment.profilePhotoUrl);

                            if (
                                recentComment.comment.split(" ")[0].toLowerCase() === currentAnswer.toLowerCase() ||
                                recentComment.comment.split(" ")[0].toLowerCase().replace(/(es|s)$/, '') === currentAnswer.toLowerCase() ||
                                (recentComment.comment.split(" ")[0].toLowerCase().replace(/(es|s)$/, '')) + "e" === currentAnswer.toLowerCase()
                            ) {
                                await sPause(3000);
                                startEffect(recentComment.profilePhotoUrl);
                                showWinnerCard(recentComment.nickname, recentComment.profilePhotoUrl);
                                guessedWords = [];
                                await addGameNumber(currentGame);
                                await sPause(6000);
                                starting = true;
                                break; // Exit loop if a winner is found
                            }
                            break; //Exit loop after 1 comment
                        }
                    }
                }

            } catch(error) {
                console.log(error);
            }
            count++;
            await sPause(500);
        }
    }

    function speakText(text) {
        if ('speechSynthesis' in window) {
            // Cancel any ongoing speech
            window.speechSynthesis.cancel();
    
            const utterance = new SpeechSynthesisUtterance(text);
            
            // Set voice to a female one if available
            const voices = window.speechSynthesis.getVoices();
            const femaleVoice = voices.find(voice => voice.name.includes('Female') || voice.gender === 'female');
            
            if (femaleVoice) {
                utterance.voice = femaleVoice;
            }
            
            // Speak the text
            window.speechSynthesis.speak(utterance);
        } else {
            console.log('Sorry, your browser does not support speech synthesis.');
        }
    }

    startGame();

})();
