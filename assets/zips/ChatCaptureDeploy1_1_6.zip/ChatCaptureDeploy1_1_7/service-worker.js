const TIKTOK_ORIGIN = 'https://www.tiktok.com';
const CONTEXTO_ORIGIN = 'https://contexto.me';
const STRIPE_CHECKOUT_ORIGIN = 'https://checkout.stripe.com';
const STRIPE_BILLING_ORIGIN = 'https://billing.stripe.com';

chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error(error));

chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (!tab.url) return;
  const url = new URL(tab.url);
  // Enables the side panel on google.com
  if (url.origin === TIKTOK_ORIGIN || url.origin === CONTEXTO_ORIGIN || 
      url.origin === STRIPE_CHECKOUT_ORIGIN || url.origin === STRIPE_BILLING_ORIGIN) {
    await chrome.sidePanel.setOptions({
      tabId,
      path: 'popup.html',
      enabled: true
    });
  } else {
    // Disables the side panel on all other sites
    await chrome.sidePanel.setOptions({
      tabId,
      enabled: false
    });
  }
});

const sPause = (milliseconds) => {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
};

